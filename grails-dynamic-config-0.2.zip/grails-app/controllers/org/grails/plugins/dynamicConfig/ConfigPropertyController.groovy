package org.grails.plugins.dynamicConfig

class ConfigPropertyController {

    def scaffold = true 
}
